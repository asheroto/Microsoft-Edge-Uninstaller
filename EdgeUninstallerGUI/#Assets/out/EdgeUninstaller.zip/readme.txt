GUI Version ---> Edge Uninstaller (GUI).exe
CMD Version ---> EdgeUninstallerCMD.exe

WARNING:
Running either will automatically start uninstalling Edge!!!